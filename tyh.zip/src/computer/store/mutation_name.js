/**
 * author:by@Deng
 * email:by@6886432@163.com
 * version:1.0
 * descriptioin: 对pcStore中的数据做处理的名称
 */
'use strict';

export default{
    LOGIN:'LOGIN',  //改变userModule模块中登录状态
}
