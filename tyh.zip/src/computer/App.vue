<template>
    <div id="app">
        <!-- pc端已经就位
        <router-link to="/components/example">跳转example</router-link> -->
        <router-view/>
    </div>
</template>

<script>

    export default {
        name: 'app',
        components:{

        }
    }
</script>

<style>

</style>
