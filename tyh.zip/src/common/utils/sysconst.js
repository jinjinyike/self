/**
 * @author:by@Deng
 * @timer:2016-12-07
 * @email:by@6886432@163.com
 * @version:1.0
 * @title:系统常量js
 */
'use strict';

export const qiNiuBaseUrl = "http://pics.ctripfair.com/"; //七牛云镜像路径
export const baseURL = process.envconfig.API_HOST; // 请求基地址
export const qiNiuCor = "http://up.qbox.me/"; //七牛云镜像地址