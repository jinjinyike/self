import Vue from 'vue'
let bus = new Vue({}); //创建事件中心
export default bus;