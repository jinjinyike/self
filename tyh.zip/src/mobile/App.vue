<template>
    <div id="app">
        移动端已经就位
        <router-view/>
    </div>
</template>

<script>
    export default {
        name: 'app'
    }
</script>

<style>

</style>
